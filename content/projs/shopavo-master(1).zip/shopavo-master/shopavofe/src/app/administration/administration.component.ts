import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { NgForm } from '@angular/forms';

import { User } from '../model/user';
import { Product } from '../model/product';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.css']
})
export class AdministrationComponent implements OnInit {

  loading = false;
    users: User[] = [];
    rows: Product[] = [];
    businessId: string;

    constructor(private productService: ProductService) { }

    ngOnInit() {
      this.getProducts();
    }
  
    hola(data: Product[]){
      var businessData = JSON.parse(localStorage.getItem("currentUser"));
      this.productService.realProducts = businessData.role;
      var finalData = new Array<Product>();
      for (var i = 0; i < data.length; i++){
        var product = <Product> data[i];
        if(businessData.role == product.businessId){
          finalData.push(product);
        }
      }
      this.productService.products = finalData;
    }

    addProduct(form?: NgForm) {
      console.log(form.value);
      if(form.value._id) {
        this.productService.putProduct(form.value)
          .subscribe(res => {
            this.resetForm(form);
            this.getProducts();
          });
      } else {
        this.productService.postProduct(form.value)
        .subscribe(res => {
          this.getProducts();
          this.resetForm(form);
        });
      }
      
    }
  
    getProducts() {

      this.productService.getAllProducts()
        .subscribe(res => {
          this.hola(res as Product[]);
        });
        
        
    }
  
    editProduct(product: Product) {
      this.productService.selectedProduct = product;
    }
  
    deleteProduct(_id: string, form: NgForm) {
      if(confirm('Are you sure you want to delete it?')) {
        this.productService.deleteProduct(_id)
          .subscribe(res => {
            this.getProducts();
            this.resetForm(form);
          });
      }
    }
  
    resetForm(form?: NgForm) {
      if (form) {
        form.reset();
        this.productService.selectedProduct = new Product();
      }
    }

}
