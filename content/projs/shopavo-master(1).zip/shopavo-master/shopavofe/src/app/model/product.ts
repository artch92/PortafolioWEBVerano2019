export class Product {
  

    constructor(_id = '', name = '', price = 0, description = '', businessId = '', quantity = 0, type = '') {
        this._id = _id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.businessId = businessId;
        this.quantity = quantity;
        this.type = type;
    }

    _id: String
    name: string;
    price: number;
    description: string;
    businessId: string;
    quantity: number;
    type: string;
}
