export enum Role {
    User = 'User',
    StiloMall= '5e23bcd95b871f55b9f2a126',
    Ekono= '5e23bdeb5b871f55b9f2a127'
}