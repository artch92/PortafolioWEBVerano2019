const productModel = require('../models/product');
const productCtrl = {};

productCtrl.getAllProducts = async (req, res) => {
    const product = await productModel.find();
    res.json(product);
};

productCtrl.addNewProduct = async (req, res, next) => {
    console.log(req.body);
    const product = new productModel({
        name: req.body.name,
        price: req.body.price,
        description: req.body.description,
        businessId: req.body.businessId,
        quantity: req.body.quantity,
        type: req.body.type
    });
    await product.save();
    res.json({status: 'Product created'});
};

productCtrl.getProduct = async (req, res, next) => {
    const { id } = req.params;
    const product = await productModel.findById(id);
    res.json(product);
};

productCtrl.editProduct = async (req, res, next) => {
    const { id } = req.params;
    const product = {
        name: req.body.name,
        price: req.body.price,
        description: req.body.description,
        businessId: req.body.businessId,
        quantity: req.body.quantity,
        type: req.body.type
    };
    await productModel.findByIdAndUpdate(id, {$set: product}, {new: true});
    res.json({status: 'Product Updated'});
};

productCtrl.deleteProduct = async (req, res, next) => {
    await productModel.findByIdAndRemove(req.params.id);
    res.json({status: 'Product Deleted'});
};

module.exports = productCtrl;
