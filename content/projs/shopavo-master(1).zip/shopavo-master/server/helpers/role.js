module.exports = {
    StiloMall: '5e23bcd95b871f55b9f2a126',
    User: 'User',
    Ekono: '5e23bdeb5b871f55b9f2a127'
  }